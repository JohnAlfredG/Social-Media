import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerblog',
  templateUrl: './registerblog.component.html',
  styleUrls: ['./registerblog.component.css']
})
export class RegisterblogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
